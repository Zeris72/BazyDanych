﻿using BLL.DTOModels;
using BLL.DTOModels.ResponseDTO;
using BLL.ServiceInterfaces.Interfaces;
using DAL;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL_DB
{
    public class ProductServiceDB :IProductService
    {
        private readonly WebstoreContext _context;
        public ProductServiceDB(WebstoreContext context)
        {
            _context = context;
        }

        public async Task<List<ProductResponseDTO>> GetProductsAsync(string? nameFilter = "name", string? groupNameFilter = null, int? groupIdFilter = null, bool includeInactive = false, string sortBy = "Name", bool ascending = true)
        {
            var parameters = new[]
            {
                new SqlParameter("@NameFilter", nameFilter ?? (object)DBNull.Value),
                new SqlParameter("@GroupNameFilter", groupNameFilter ?? (object)DBNull.Value),
                new SqlParameter("@GroupIdFilter", groupIdFilter ?? (object)DBNull.Value),
                new SqlParameter("@IncludeInactive", includeInactive),
                new SqlParameter("@SortBy", sortBy),
                new SqlParameter("@Ascending", ascending)
            };

            // Wywołanie procedury składowanej
            var result = await _context.Database.ExecuteSqlRawAsync(
                "EXEC [dbo].[GetProducts] @NameFilter, @GroupNameFilter, @GroupIdFilter, @IncludeInactive, @SortBy, @Ascending", parameters);

            // Mapowanie wyników na DTO
            var products = new List<ProductResponseDTO>();

            using (var command = _context.Database.GetDbConnection().CreateCommand())
            {
                command.CommandText = "EXEC [dbo].[GetProducts] @NameFilter, @GroupNameFilter, @GroupIdFilter, @IncludeInactive, @SortBy, @Ascending";
                command.Parameters.AddRange(parameters);

                _context.Database.OpenConnection();

                using (var reader = await command.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        var product = new ProductResponseDTO(
                            reader.GetInt32(reader.GetOrdinal("ID")),
                            reader.GetString(reader.GetOrdinal("Name")),
                            reader.GetDecimal(reader.GetOrdinal("Price")),
                            reader.GetString(reader.GetOrdinal("Image")),
                            reader.GetBoolean(reader.GetOrdinal("IsActive")),
                            reader.GetString(reader.GetOrdinal("GroupName"))
                        );

                        products.Add(product);
                    }
                }
            }
            return products;
        }

        public async Task DeactivateProductAsync(int productId)
        {
            var productIdParam = new SqlParameter("@ProductId", productId);
            await _context.Database.ExecuteSqlRawAsync("EXEC [dbo].[DeactivateProduct] @ProductId", productIdParam);
        }

        public async Task ActivateProductAsync(int productId)
        {
            var productIdParam = new SqlParameter("@ProductId", productId);
            await _context.Database.ExecuteSqlRawAsync("EXEC [dbo].[ActivateProduct] @ProductId", productIdParam);
        }

        public async Task AddProductAsync(ProductRequestDTO productRequest)
        {
            var parameters = new[]
            {
                new SqlParameter("@Name", productRequest.Name),
                new SqlParameter("@Price", productRequest.Price),
                new SqlParameter("@Image", productRequest.Image),
                new SqlParameter("@GroupID", productRequest.GroupID)
            };

            await _context.Database.ExecuteSqlRawAsync("EXEC [dbo].[AddProduct] @Name, @Price, @Image, @GroupID", parameters);
        }

        public async Task DeleteProductAsync(int productId)
        {
            // Parametr dla procedury składowanej
            var productIdParam = new SqlParameter("@ProductID", productId);

            try
            {
                var result = await _context.Database.ExecuteSqlRawAsync(
                    "EXEC [dbo].[RemoveProduct] @ProductID", productIdParam);

                //return "Operacja zakończona powodzeniem";
            }
            catch (Exception ex)
            {
                // Obsługa błędów
                //return $"Wystąpił błąd podczas usuwania produktu: {ex.Message}";
            }
        }

        public async Task<bool> CanDeleteProductAsync(int productId)
        {
            return !await _context.OrderPositions.AnyAsync(op => op.ProductID == productId);
        }

        public async Task AddToCartAsync(int productId, int userId, int amount)
        {
            // Parametry dla procedury składowanej
            var productIdParam = new SqlParameter("@ProductID", productId);
            var userIdParam = new SqlParameter("@UserID", userId);
            var amountParam = new SqlParameter("@Amount", amount);

            try
            {
                // Wywołanie procedury składowanej w bazie danych
                await _context.Database.ExecuteSqlRawAsync(
                    "EXEC [dbo].[AddToCart] @ProductID, @UserID, @Amount", productIdParam, userIdParam, amountParam);
            }
            catch (Exception ex)
            {
                // Obsługa błędów
                throw new Exception($"Błąd podczas dodawania produktu do koszyka: {ex.Message}");
            }
        }

        public async Task UpdateProductAmountInCartAsync(int productId, int userId, int amount)
        {
            // Parametry dla procedury składowanej
            var productIdParam = new SqlParameter("@ProductID", productId);
            var userIdParam = new SqlParameter("@UserID", userId);
            var amountParam = new SqlParameter("@Amount", amount);

            try
            {
                // Wywołanie procedury składowanej w bazie danych
                await _context.Database.ExecuteSqlRawAsync(
                    "EXEC [dbo].[UpdateProductAmountInCart] @ProductID, @UserID, @Amount", productIdParam, userIdParam, amountParam);
            }
            catch (Exception ex)
            {
                // Obsługa błędów
                throw new Exception($"Błąd podczas aktualizacji ilości produktu w koszyku: {ex.Message}");
            }
        }

        public async Task RemoveFromCartAsync(int productId, int userId)
        {
            // Parametry dla procedury składowanej
            var productIdParam = new SqlParameter("@ProductID", productId);
            var userIdParam = new SqlParameter("@UserID", userId);

            try
            {
                // Wywołanie procedury składowanej w bazie danych
                await _context.Database.ExecuteSqlRawAsync(
                    "EXEC [dbo].[RemoveFromCart] @ProductID, @UserID", productIdParam, userIdParam);
            }
            catch (Exception ex)
            {
                // Obsługa błędów
                throw new Exception($"Błąd podczas usuwania produktu z koszyka: {ex.Message}");
            }
        }
    }
}
