﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.DTOModels.ResponseDTO
{
    public class ProductResponseDTO
    {
        public int ID { get;}
        public string Name { get; }
        public double Price { get; }
        public string Image { get; }
        public bool IsActive { get; }
        public int? GroupID { get; }

        public ProductResponseDTO(int id,string name, double price, string image, bool isActive, int? groupID)
        {
            ID = id;
            Name = name;
            Price = price;
            Image = image;
            IsActive = isActive;
            GroupID = groupID;
        }
    }
}
