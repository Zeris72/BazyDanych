﻿using BLL.DTOModels.ResponseDTO;
using BLL.DTOModels;
using BLL.ServiceInterfaces.Interfaces;
using DAL;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace BLL_EF
{
    public class ProductService : IProductService
    {
        private readonly WebstoreContext _context;

        public ProductService(WebstoreContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<ProductResponseDTO>> GetProductsAsync(
            string nameFilter = null,
            string groupNameFilter = null,
            int? groupIdFilter = null,
            bool includeInactive = false,
            string sortBy = "Name",
            bool ascending = true)
        {
            var query = _context.Products.AsQueryable();

            // Filtracja po nazwie
            if (!string.IsNullOrEmpty(nameFilter))
            {
                query = query.Where(p => p.Name.Contains(nameFilter));
            }

            // Filtracja po nazwie grupy, jeśli podano
            if (!string.IsNullOrEmpty(groupNameFilter))
            {
                query = query.Where(p => p.ProductGroup.Name.Contains(groupNameFilter));
            }

            // Filtracja po grupie, jeśli podano
            if (groupIdFilter.HasValue)
            {
                query = query.Where(p => p.GroupID == groupIdFilter.Value);
            }

            // Uwzględnienie nieaktywnych produktów
            if (!includeInactive)
            {
                query = query.Where(p => p.IsActive);
            }

            // Sortowanie
            if (ascending)
            {
                query = sortBy switch
                {
                    "Name" => query.OrderBy(p => p.Name),
                    "Price" => query.OrderBy(p => p.Price),
                    "ID" => query.OrderBy(p => p.ID),
                    _ => query.OrderBy(p => p.Name)
                };
            }
            else
            {
                query = sortBy switch
                {
                    "Name" => query.OrderByDescending(p => p.Name),
                    "Price" => query.OrderByDescending(p => p.Price),
                    "ID" => query.OrderByDescending(p => p.ID),
                    _ => query.OrderByDescending(p => p.Name)
                };
            }

            var products = await query
                .Select(p => new ProductResponseDTO
                (
                    p.ID,
                    p.Name,
                    p.Price,
                    p.Image,
                    p.IsActive,
                    p.GroupID
                ))
                .ToListAsync();

            return products;
        }

        public async Task<ProductResponseDTO> AddProductAsync(ProductRequestDTO productRequest)
        {
            var newProduct = new Product
            {
                Name = productRequest.Name,
                Price = productRequest.Price,
                Image = productRequest.Image,
                IsActive = true,
                GroupID = productRequest.GroupID,
            };

            _context.Products.Add(newProduct);
            await _context.SaveChangesAsync();

            return new ProductResponseDTO
            (
                newProduct.ID,
                newProduct.Name,
                newProduct.Price,
                newProduct.Image,
                newProduct.IsActive,
                newProduct.GroupID
            );
        }

        public async Task DeactivateProductAsync(int productId)
        {
            var product = await _context.Products.FindAsync(productId);
            if (product != null)
            {
                product.IsActive = false;
                await _context.SaveChangesAsync();
            }
        }

        public async Task ActivateProductAsync(int productId)
        {
            var product = await _context.Products.FindAsync(productId);
            if (product != null)
            {
                product.IsActive = true;
                await _context.SaveChangesAsync();
            }
        }

        public async Task DeleteProductAsync(int productId)
        {
            var product = await _context.Products.FindAsync(productId);
            if (product != null)
            {
                _context.Products.Remove(product);
                await _context.SaveChangesAsync();
            }
        }

        public async Task AddToCartAsync(int productId, int userId, int amount)
        {
            var product = await _context.Products.FindAsync(productId);
            var user = await _context.Users.FindAsync(userId);

            if (product != null && user != null)
            {
                var basketPosition = new BasketPosition
                {
                    ProductID = productId,
                    UserID = userId,
                    Amount = amount
                };

                _context.BasketPositions.Add(basketPosition);
                await _context.SaveChangesAsync();
            }
        }

        public async Task UpdateProductAmountInCartAsync(int productId, int userId, int amount)
        {
            var basketPosition = await _context.BasketPositions
                .FirstOrDefaultAsync(bp => bp.ProductID == productId && bp.UserID == userId);

            if (basketPosition != null)
            {
                basketPosition.Amount = amount;
                await _context.SaveChangesAsync();
            }
        }

        public async Task RemoveFromCartAsync(int productId, int userId)
        {
            var basketPosition = await _context.BasketPositions
                .FirstOrDefaultAsync(bp => bp.ProductID == productId && bp.UserID == userId);

            if (basketPosition != null)
            {
                _context.BasketPositions.Remove(basketPosition);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<OrderResponseDTO> GenerateOrderAsync(int userId)
        {
            var user = await _context.Users.FindAsync(userId);
            var basketItems = await _context.BasketPositions
                .Where(bp => bp.UserID == userId)
                .Include(bp => bp.Product)
                .ToListAsync();

            if (user == null || basketItems.Count == 0)
            {
                return null; // Brak użytkownika lub produktów w koszyku
            }

            var totalAmount = basketItems.Sum(bp => bp.Product.Price * bp.Amount);
            var newOrder = new Order
            {
                UserID = userId,
                Date = DateTime.Now,
                IsPaid = false
            };

            _context.Orders.Add(newOrder);
            await _context.SaveChangesAsync();

            foreach (var item in basketItems)
            {
                var orderPosition = new OrderPosition
                {
                    OrderID = newOrder.ID,
                    ProductID = item.ProductID,
                    Amount = item.Amount,
                    Price = item.Product.Price
                };

                _context.OrderPositions.Add(orderPosition);
            }

            await _context.SaveChangesAsync();

            // Przenieś produkty z koszyka do zamówienia
            foreach (var item in basketItems)
            {
                _context.BasketPositions.Remove(item);
            }

            await _context.SaveChangesAsync();

            return new OrderResponseDTO
            (
                newOrder.ID,
                newOrder.OrderPositions.Sum(op=>op.Amount),
                newOrder.IsPaid,
                newOrder.Date
            );
        }

        public async Task PayOrderAsync(int orderId, decimal amountPaid)
        {
            var order = await _context.Orders.FindAsync(orderId);
            if (order != null && amountPaid >= order.OrderPositions.Sum(op=>op.Amount))
            {
                order.IsPaid = true;
                await _context.SaveChangesAsync();
            }
        }
    }
}
