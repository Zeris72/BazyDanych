﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class User
    {
        [BsonId]
        [BsonRepresentation(BsonType.String)]
        public string Id { get; set; }

        public string Login { get; set; }
        public string Password { get; set; }
        public Type Type { get; set; }
        public bool IsActive { get; set; }

        public int? GroupId { get; set; }
        public UserGroup? UserGroup { get; set; } // lub pominąć i pobierać osobno
    }
}
