﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    using MongoDB.Bson;
    using MongoDB.Bson.Serialization.Attributes;

    public class BasketPosition
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }  // Mongo potrzebuje unikalnego klucza – generujemy go automatycznie

        public int ProductID { get; set; }
        public int UserID { get; set; }
        public int Amount { get; set; }
    }
}
