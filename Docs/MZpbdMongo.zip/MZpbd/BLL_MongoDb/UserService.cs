﻿using BLL.DTOModels.ResponseDTO;
using BLL.ServiceInterfaces.Interfaces;
using Model;
using MongoDB.Driver;
using System;
using System.Threading.Tasks;

namespace BLL_Mongo
{
    public class UserService : IUserService
    {
        private readonly IMongoCollection<User> _users;

        public UserService(IMongoDatabase database)
        {
            _users = database.GetCollection<User>("Users");
        }

        public async Task<UserResponseDTO> LoginAsync(string login, string password)
        {
            var filter = Builders<User>.Filter.And(
                Builders<User>.Filter.Eq(u => u.Login, login),
                Builders<User>.Filter.Eq(u => u.Password, password),
                Builders<User>.Filter.Eq(u => u.IsActive, true)
            );

            var user = await _users.Find(filter).FirstOrDefaultAsync();

            if (user == null)
                return null;

            return new UserResponseDTO(
                int.Parse(user.Id),
                user.Login,
                user.Password,
                user.Type.ToString(),
                user.IsActive,
                user.GroupId
            );
        }

        public async Task LogoutAsync()
        {
            // Tu również możesz zintegrować token/session logic jeśli chcesz
            await Task.CompletedTask;
        }
    }
}
