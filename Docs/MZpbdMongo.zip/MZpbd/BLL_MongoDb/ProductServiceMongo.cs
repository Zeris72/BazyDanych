﻿using BLL.DTOModels.ResponseDTO;
using BLL.DTOModels;
using BLL.ServiceInterfaces.Interfaces;
using MongoDB.Driver;
using DALMongo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;

namespace BLL_MongoDb
{
    public class ProductServiceMongo:IProductService
    {
        private readonly IMongoCollection<Product> _products;
        private readonly IMongoCollection<ProductGroup> _productGroups;
        private readonly IMongoCollection<User> _users;
        private readonly IMongoCollection<BasketPosition> _basketPositions;
        private readonly IMongoCollection<OrderPosition> _orderPositions;

        public ProductServiceMongo(WebStoreMongoContext context)
        {
            _products = context.Products;
            _productGroups = context.ProductGroups;
            _users = context.Users;
            _basketPositions = context.BasketPositions;
            _orderPositions = context.OrderPositions;
        }

        public async Task<List<ProductResponseDTO>> GetProductsAsync(
            string? nameFilter = null,
            string? groupNameFilter = null,
            int? groupIdFilter = null,
            bool includeInactive = false,
            string sortBy = "Name",
            bool ascending = true)
        {
            var filterBuilder = Builders<Product>.Filter;
            var filter = filterBuilder.Empty;

            if (!string.IsNullOrEmpty(nameFilter))
                filter &= filterBuilder.Regex(p => p.Name, new MongoDB.Bson.BsonRegularExpression(nameFilter, "i"));

            if (groupIdFilter.HasValue)
                filter &= filterBuilder.Eq(p => p.GroupID, groupIdFilter.Value);

            if (!includeInactive)
                filter &= filterBuilder.Eq(p => p.IsActive, true);

            var products = await _products.Find(filter).ToListAsync();

            var groupDict = _productGroups.Find(_=>true).ToList().ToDictionary(g => g.Id, g => g);

            // Sort manually
            products = sortBy switch
            {
                "Price" => ascending ? products.OrderBy(p => p.Price).ToList() : products.OrderByDescending(p => p.Price).ToList(),
                "GroupName" => ascending ? products.OrderBy(p => groupDict.TryGetValue((p.GroupID ?? -1).ToString(), out var g) ? g.Name : "").ToList() :
                                           products.OrderByDescending(p => groupDict.TryGetValue((p.GroupID ?? -1).ToString(), out var g) ? g.Name : "").ToList(),
                _ => ascending ? products.OrderBy(p => p.Name).ToList() : products.OrderByDescending(p => p.Name).ToList()
            };

            if (!string.IsNullOrEmpty(groupNameFilter))
            {
                products = products
                    .Where(p =>
                        groupDict.TryGetValue((p.GroupID ?? -1).ToString(), out var group) &&
                        BuildFullPath(group, groupDict)
                        .Split('/')
                        .Any(segment => segment.Contains(groupNameFilter, StringComparison.OrdinalIgnoreCase)))
                    .ToList();
            }

            return products.Select(p => new ProductResponseDTO(
                int.Parse(p.Id),
                p.Name,
                p.Price,
                p.Image,
                p.IsActive,
                p.GroupID.HasValue && groupDict.TryGetValue(p.GroupID.Value.ToString(), out var group)
                    ? BuildFullPath(group, groupDict)
                    : ""
            )).ToList();
        }

        private string BuildFullPath(ProductGroup group, Dictionary<string, ProductGroup> allGroups)
        {
            var segments = new List<string>();
            while (group != null)
            {
                segments.Insert(0, group.Name);
                if (group.ParentId.Length>0 && allGroups.TryGetValue(group.ParentId, out var parent))
                {
                    group = parent;
                }
                else
                {
                    break;
                }
            }
            return string.Join("/", segments);
        }

        public async Task AddProductAsync(ProductRequestDTO productRequest)
        {
            var newProduct = new Product
            {
                Id = GenerateRandomId().ToString(),
                Name = productRequest.Name,
                Price = productRequest.Price,
                Image = productRequest.Image,
                IsActive = true,
                GroupID = productRequest.GroupID,
            };

            await _products.InsertOneAsync(newProduct);
        }

        public async Task DeactivateProductAsync(int productId)
        {
            var update = Builders<Product>.Update.Set(p => p.IsActive, false);
            await _products.UpdateOneAsync(p => p.Id == productId.ToString(), update);
        }

        public async Task ActivateProductAsync(int productId)
        {
            var update = Builders<Product>.Update.Set(p => p.IsActive, true);
            await _products.UpdateOneAsync(p => p.Id == productId.ToString(), update);
        }

        public async Task DeleteProductAsync(int productId)
        {
            await _products.DeleteOneAsync(p => p.Id == productId.ToString());
        }

        public async Task<bool> CanDeleteProductAsync(int productId)
        {
            var exists = await _orderPositions.Find(op => op.ProductID == productId).AnyAsync();
            return !exists;
        }

        public async Task AddToCartAsync(int productId, int userId, int amount)
        {
            var existing = await _basketPositions
                .Find(bp => bp.UserID == userId && bp.ProductID == productId)
                .FirstOrDefaultAsync();

            if (existing != null)
            {
                var update = Builders<BasketPosition>.Update.Inc(bp => bp.Amount, amount);
                await _basketPositions.UpdateOneAsync(bp => bp.UserID == userId && bp.ProductID == productId, update);
            }
            else
            {
                var position = new BasketPosition
                {
                    UserID = userId,
                    ProductID = productId,
                    Amount = amount
                };
                await _basketPositions.InsertOneAsync(position);
            }
        }

        public async Task UpdateProductAmountInCartAsync(int productId, int userId, int amount)
        {
            var update = Builders<BasketPosition>.Update.Set(bp => bp.Amount, amount);
            await _basketPositions.UpdateOneAsync(bp => bp.ProductID == productId && bp.UserID == userId, update);
        }

        public async Task RemoveFromCartAsync(int productId, int userId)
        {
            await _basketPositions.DeleteOneAsync(bp => bp.ProductID == productId && bp.UserID == userId);
        }

        private int GenerateRandomId()
        {
            return new Random().Next(100000, 999999); // Zamienisz to później np. na sekwencję lub ObjectId
        }
    }
}
