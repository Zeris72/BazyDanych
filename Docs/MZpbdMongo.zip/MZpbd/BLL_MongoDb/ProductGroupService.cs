﻿using BLL.DTOModels.RequestsDTO;
using BLL.DTOModels.ResponseDTO;
using BLL.ServiceInterfaces.Interfaces;
using Model;
using MongoDB.Driver;
using System.Linq;

namespace BLL_Mongo
{
    public class ProductGroupService : IProductGroupService
    {
        private readonly IMongoCollection<ProductGroup> _productGroups;

        public ProductGroupService(IMongoDatabase database)
        {
            _productGroups = database.GetCollection<ProductGroup>("ProductGroups");
        }

        public async Task<IEnumerable<ProductGroupResponseDTO>> GetProductGroupsAsync(
            bool topGroups = false,
            int? groupId = null,
            string sortBy = "Name",
            bool ascending = true)
        {
            var filter = Builders<ProductGroup>.Filter.Empty;

            if (topGroups)
            {
                filter &= Builders<ProductGroup>.Filter.Eq(pg => pg.ParentId, null);
            }

            if (groupId.HasValue)
            {
                filter &= Builders<ProductGroup>.Filter.Or(
                    Builders<ProductGroup>.Filter.Eq(pg => pg.Id, groupId.ToString()),
                    Builders<ProductGroup>.Filter.Eq(pg => pg.ParentId, groupId.ToString()));
            }

            var allGroups = await _productGroups.Find(_ => true).ToListAsync();
            var groupDict = allGroups.ToDictionary(pg => pg.Id);

            var selectedGroupsList = await _productGroups.Find(filter).ToListAsync();

            var dtoList = selectedGroupsList
                .Select(pg => new ProductGroupResponseDTO
                (
                    int.Parse(pg.Id),
                    pg.Name,
                    int.Parse(pg.ParentId),
                    BuildFullPath(pg, groupDict)
                ))
                .ToList();

            // Sortowanie
            dtoList = sortBy switch
            {
                "Name" => ascending ? dtoList.OrderBy(dto => dto.Path).ToList() : dtoList.OrderByDescending(dto => dto.Path).ToList(),
                "ID" => ascending ? dtoList.OrderBy(dto => dto.ID).ToList() : dtoList.OrderByDescending(dto => dto.ID).ToList(),
                _ => dtoList.OrderBy(dto => dto.Path).ToList()
            };

            return dtoList;
        }

        private string BuildFullPath(ProductGroup group, Dictionary<string, ProductGroup> groupDict)
        {
            var pathSegments = new List<string>();
            while (group != null)
            {
                pathSegments.Insert(0, group.Name);
                group = group.ParentId.Length>0 && groupDict.ContainsKey(group.ParentId)
                    ? groupDict[group.ParentId]
                    : null;
            }
            return string.Join("/", pathSegments);
        }

        public async Task<ProductGroupResponseDTO> AddProductGroupAsync(ProductGroupRequestDTO groupRequest)
        {
            var newGroup = new ProductGroup
            {
                Id = GenerateNewGroupId().ToString(),
                Name = groupRequest.Name,
                ParentId = groupRequest.ToString()
            };

            await _productGroups.InsertOneAsync(newGroup);

            return new ProductGroupResponseDTO
            (
                int.Parse(newGroup.Id),
                newGroup.Name,
                int.Parse(newGroup.Id),
                null
            );
        }

        private int GenerateNewGroupId()
        {
            // Przykładowe generowanie ID (w Mongo nie ma auto-incrementu)
            var last = _productGroups.Find(_ => true).SortByDescending(pg => pg.Id).Limit(1).FirstOrDefault();
            return (last != null ? int.Parse(last.Id) + 1 : 1);
        }
    }
}
