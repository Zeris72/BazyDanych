﻿using BLL.DTOModels.ResponseDTO;
using BLL.ServiceInterfaces.Interfaces;
using Model;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL_MongoDb
{
    public class OrderServiceMongo : IOrderService
    {
        private readonly IMongoCollection<Order> _orders;
        private readonly IMongoCollection<OrderPosition> _orderPositions;
        private readonly IMongoCollection<BasketPosition> _basketPositions;
        private readonly IMongoCollection<Product> _products;
        private readonly IMongoCollection<User> _users;

        public OrderServiceMongo(IMongoDatabase database)
        {
            _orders = database.GetCollection<Order>("Orders");
            _orderPositions = database.GetCollection<OrderPosition>("OrderPositions");
            _basketPositions = database.GetCollection<BasketPosition>("BasketPositions");
            _products = database.GetCollection<Product>("Products");
            _users = database.GetCollection<User>("Users");
        }

        public async Task<IEnumerable<OrderResponseDTO>> GetOrdersAsync(string orderIdFilter = null, bool? isPaidFilter = null, string sortBy = "ID", bool ascending = true)
        {
            var filter = Builders<Order>.Filter.Empty;

            if (!string.IsNullOrEmpty(orderIdFilter) && int.TryParse(orderIdFilter, out var orderId))
                filter &= Builders<Order>.Filter.Eq(o => o.Id, orderId.ToString());

            if (isPaidFilter.HasValue)
                filter &= Builders<Order>.Filter.Eq(o => o.IsPaid, isPaidFilter.Value);

            var sort = sortBy switch
            {
                "OrderDate" => ascending ? Builders<Order>.Sort.Ascending(o => o.Date) : Builders<Order>.Sort.Descending(o => o.Date),
                _ => ascending ? Builders<Order>.Sort.Ascending(o => o.Id) : Builders<Order>.Sort.Descending(o => o.Id)
            };

            var orders = await _orders.Find(filter).Sort(sort).ToListAsync();

            var result = new List<OrderResponseDTO>();
            foreach (var order in orders)
            {
                var positions = await _orderPositions.Find(op => op.OrderId.ToString() == order.Id).ToListAsync();
                var total = positions.Sum(p => p.Price * p.Amount);

                result.Add(new OrderResponseDTO(int.Parse(order.Id), total, order.IsPaid, order.Date));
            }

            return result;
        }

        public async Task<OrderPositionResponseDTO> GetOrderPositionAsync(int orderId)
        {
            var position = await _orderPositions.Find(op => op.OrderId == orderId).FirstOrDefaultAsync();
            if (position == null) return null;

            var product = await _products.Find(p => p.Id == position.ProductID.ToString()).FirstOrDefaultAsync();

            return new OrderPositionResponseDTO(
                product?.Name ?? "Unknown",
                position.Price,
                position.Amount,
                position.Price * position.Amount);
        }

        public async Task<OrderResponseDTO> GenerateOrderAsync(int userId)
        {
            //var user = await _users.Find(u => u.Id == userId.ToString()).FirstOrDefaultAsync();
            var basket = await _basketPositions.Find(bp => bp.UserID == userId).ToListAsync();

            if (!basket.Any()) return null;

            var total = 0m;
            var order = new Order
            {
                Id="1",
                UserID = userId,
                Date = DateTime.Now,
                IsPaid = false,
                Value = 0 // will be calculated after positions
            };

            await _orders.InsertOneAsync(order);

            foreach (var item in basket)
            {
                var product = await _products.Find(p => p.Id == item.ProductID.ToString()).FirstOrDefaultAsync();
                var price = product?.Price ?? 0m;
                total += price * item.Amount;

                await _orderPositions.InsertOneAsync(new OrderPosition
                {
                    OrderId = int.Parse(order.Id),
                    ProductID = item.ProductID,
                    Price = price,
                    Amount = item.Amount
                });
            }

            var update = Builders<Order>.Update.Set(o => o.Value, total);
            await _orders.UpdateOneAsync(o => o.Id == order.Id, update);

            await _basketPositions.DeleteManyAsync(bp => bp.UserID == userId);

            return new OrderResponseDTO(int.Parse(order.Id), total, order.IsPaid, order.Date);
        }

        public async Task PayOrderAsync(int orderId, decimal amountPaid)
        {
            var positions = await _orderPositions.Find(op => op.OrderId == orderId).ToListAsync();
            var total = positions.Sum(op => op.Price * op.Amount);

            if (amountPaid >= total)
            {
                var update = Builders<Order>.Update.Set(o => o.IsPaid, true);
                await _orders.UpdateOneAsync(o => o.Id == orderId.ToString(), update);
            }
        }
    }
}
