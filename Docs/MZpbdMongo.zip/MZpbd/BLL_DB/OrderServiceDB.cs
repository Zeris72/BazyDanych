﻿using BLL.DTOModels.ResponseDTO;
using BLL.ServiceInterfaces.Interfaces;
using DAL;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL_DB
{
    public class OrderServiceDB:IOrderService
    {
        private readonly WebstoreContext _context;

        public OrderServiceDB(WebstoreContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<OrderResponseDTO>> GetOrdersAsync(
            string orderIdFilter = null,
            bool? isPaidFilter = null,
            string sortBy = "ID",
            bool ascending = true)
        {
            var orders = new List<OrderResponseDTO>();

            // Przygotowanie parametrów
            var orderIdParam = new SqlParameter("@OrderIdFilter", string.IsNullOrEmpty(orderIdFilter) ? (object)DBNull.Value : int.Parse(orderIdFilter));
            var isPaidParam = new SqlParameter("@IsPaidFilter", isPaidFilter.HasValue ? (object)isPaidFilter.Value : DBNull.Value);
            var sortByParam = new SqlParameter("@SortBy", sortBy);
            var ascendingParam = new SqlParameter("@Ascending", ascending);

            // Użycie DbCommand do wykonania zapytania
            using (var command = _context.Database.GetDbConnection().CreateCommand())
            {
                command.CommandText = "EXEC [dbo].[GetOrders] @OrderIdFilter, @IsPaidFilter, @SortBy, @Ascending";
                command.Parameters.AddRange(new[] { orderIdParam, isPaidParam, sortByParam, ascendingParam });

                // Upewniamy się, że połączenie jest otwarte
                if (command.Connection.State != System.Data.ConnectionState.Open)
                {
                    await command.Connection.OpenAsync();
                }

                // Wykonanie zapytania i przetwarzanie wyników
                using (var reader = await command.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        var order = new OrderResponseDTO(
                            reader.GetInt32(reader.GetOrdinal("ID")),
                            reader.GetDecimal(reader.GetOrdinal("TotalAmount")),  // Przykład, zamień na odpowiednią kolumnę
                            reader.GetBoolean(reader.GetOrdinal("IsPaid")),
                            reader.GetDateTime(reader.GetOrdinal("OrderDate"))
                        );

                        orders.Add(order);
                    }
                }
            }
            return orders;
        }

        public async Task<OrderPositionResponseDTO> GetOrderPositionAsync(int orderId)
        {
            var orderIdParam = new SqlParameter("@OrderID", orderId);

            var orderPosition = await _context.OrderPositions
                .FromSqlRaw("EXEC [dbo].[GetOrderPosition] @OrderID", orderIdParam)
                .Select(op => new OrderPositionResponseDTO
                (
                    op.Product.Name,
                    op.Price,
                    op.Amount,
                    op.Price * op.Amount
                ))
                .ToListAsync();

            if (orderPosition == null || !orderPosition.Any())
            {
                return null;
            }

            return orderPosition.First();
        }

        public async Task<OrderResponseDTO> GenerateOrderAsync(int userId)
        {
            // Parametr do procedury składowanej
            var userIdParam = new SqlParameter("@UserID", userId);

            // Wykonanie procedury składowanej i pobranie wyników
            var order = await _context.Orders
                .FromSqlRaw("EXEC [dbo].[GenerateOrder] @UserID", userIdParam)
                .ToListAsync();

            // Sprawdzenie, czy zwrócono zamówienie
            if (order == null || !order.Any())
            {
                return null; // W przypadku braku zamówienia
            }

            var newOrder = order.First();

            // Zwrócenie odpowiedzi DTO
            return new OrderResponseDTO
            (
                newOrder.ID,
                newOrder.OrderPositions.Sum(op => op.Amount * op.Price), // Obliczanie wartości zamówienia
                newOrder.IsPaid,
                newOrder.Date
            );
        }

        public async Task PayOrderAsync(int orderId, decimal amountPaid)
        {
            var orderIdParam = new SqlParameter("@OrderID", orderId);
            var amountPaidParam = new SqlParameter("@AmountPaid", amountPaid);

            await _context.Database.ExecuteSqlRawAsync(
                "EXEC [dbo].[PayOrder] @OrderID, @AmountPaid", orderIdParam, amountPaidParam);
        }
    }
}
