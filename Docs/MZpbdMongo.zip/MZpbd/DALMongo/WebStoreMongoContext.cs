﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;
using MongoDB.Bson;
using MongoDB.Driver;

namespace DALMongo
{
    public class WebStoreMongoContext
    {
        private readonly IMongoDatabase _database;

        public WebStoreMongoContext(IMongoClient mongoClient)
        {
            _database = mongoClient.GetDatabase("PB");
        }
        public IMongoCollection<Product> Products=> _database.GetCollection<Product>("Products");
        public IMongoCollection<Order> Orders => _database.GetCollection<Order>("Order");
        public IMongoCollection<ProductGroup> ProductGroups => _database.GetCollection<ProductGroup>("ProductGroups");
        public IMongoCollection<User> Users => _database.GetCollection<User>("Users");
        public IMongoCollection<UserGroup> UserGroups => _database.GetCollection<UserGroup>("UserGroups");
        public IMongoCollection<BasketPosition> BasketPositions => _database.GetCollection<BasketPosition>("BasketPositions");
        public IMongoCollection<OrderPosition> OrderPositions => _database.GetCollection<OrderPosition>("OrderPositions");
    }
}
